var Clmongoose = require("mongoose");
var ClSchema = Clmongoose.Schema;
var ClockSchema = new ClSchema({
    Hour:Number,
    Min:Number,
    Numbers: Number,
    Check:Boolean
});
var Clocks = Clmongoose.model("Clocks", ClockSchema);

module.exports = Clocks;