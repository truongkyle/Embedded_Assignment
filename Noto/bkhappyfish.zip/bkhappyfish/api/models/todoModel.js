var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var TodoSchema = new Schema({
    Temperature: String,
    Date: Date
});
var Todos = mongoose.model("Todos", TodoSchema);

module.exports = Todos;
