var Todos = require("../models/todoModel");

module.exports = function (data) {
    var seedTodos = {
        Temperature: data.Temperature,
        Date: data.Date

    };
    Todos.create(seedTodos, function (err, result) {
        if (err) throw err;
    });


}