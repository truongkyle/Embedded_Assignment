var Todos =require("../models/todoModel");
function getTodos(res){
    Todos.find(function(err,result){
        if(err) {
            res.status(500).json(err);
        } else {
          
            res.json(result);
        }
    });
}

module.exports = function(app){
    // get all todos
    app.get("/api/todos",function(req,res){
        getTodos(res);
    });
    // 
    app.get("/api/todos/:id",function(req,res){
        Todos.findById({_id: req.params.id},function(err,result){
            if(err) {
                res.status(500).json(err);
            } else{
                res.json(result);
            }
        });
    });

    // post
    app.post("/api/todos",function(req,res){
        var creat = {
            text : req.body.text,
            isDone: req.body.isDone
        };
        console.log(creat.text);
        Todos.create(creat,function(err,result){
            if(err) {
                res.status(500).json(err);
            } else{
                getTodos(res);
            }
        })

    });

    //update
    app.put("/api/todos",function(req,res){
        if(!req.body._id){
            res.status(500).send("ID required");
        } else{
            Todos.update({
                _id: req.body._id
            },{
                text: req.body.text,
                isDone:req.body.isDone
             
                
            },function(err,result){
                if(err) {
                    res.status(500).json(err);
                } else{
                    getTodos(res);
                }

            });
        }
    });

    //delete

    app.delete("/api/todos/:id",function(req,res){
        Todos.remove({_id:req.params.id},function(err,result){
            if(err) { res.status(500).json(err);}
            else{
                getTodos(res);
            }
        });

    });
}