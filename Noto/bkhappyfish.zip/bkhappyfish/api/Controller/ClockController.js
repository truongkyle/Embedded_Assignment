var Clocks = require("../models/clockModel");
function getClocks(res) {
    Clocks.find(function (err, result) {
        if (err) {
            res.status(500).json(err);
        } else {

            res.json(result);
        }
    });
}

module.exports = function (app) {
    // get all Clocks
    app.get("/api/Clocks", function (req, res) {
        getClocks(res);
    });
    // 
    app.get("/api/Clocks/:id", function (req, res) {
        Clocks.findById({ _id: req.params.id }, function (err, result) {
            if (err) {
                res.status(500).json(err);
            } else {
                res.json(result);
            }
        });
    });

    // post
    app.post("/api/Clocks", function (req, res) {
        var creat = {
            Hour: req.body.Hour,
            Min: req.body.Min,
            Numbers: req.body.Numbers,
            Check: req.body.Check
        };
        console.log(creat);
        Clocks.create(creat, function (err, result) {
            if (err) {
                res.status(500).json(err);
            } else {
                getClocks(res);
            }
        })

    });

    //update
    app.put("/api/Clocks", function (req, res) {
        if (!req.body._id) {
            res.status(500).send("ID required");
        } else {
            Clocks.update({
                _id: req.body._id
            }, {
                    Hour: req.body.Hour,
                    Min: req.body.Min,
                    Numbers: req.body.Numbers,
                    Check: req.body.Check


                }, function (err, result) {
                    if (err) {
                        res.status(500).json(err);
                    } else {
                        getClocks(res);
                    }

                });
        }
    });

    //delete

    app.delete("/api/Clocks/:id", function (req, res) {
        Clocks.remove({ _id: req.params.id }, function (err, result) {
            if (err) { res.status(500).json(err); }
            else {
                getClocks(res);
            }
        });

    });
}