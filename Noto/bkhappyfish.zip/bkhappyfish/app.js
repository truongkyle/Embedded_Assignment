var express = require("express");
var Parser = require("body-parser");
var morgan = require("morgan");
var mongoose = require("mongoose");
var Clmongoose = require("mongoose");
var config = require("./config");
var configClock = require("./configClock");
var setupController = require("./api/Controller/setupController");
var todosController = require("./api/Controller/todoController");
var ClockController = require("./api/Controller/ClockController");
var setupController = require("./api/Controller/setupController");
var middleware = require('socketio-wildcard')();
var socketio = require("socket.io");
var ip = require("ip");
var age =0;
var start={
    "Numbers":5
};
var truongky = {
    "name": "truong ky lee",
    "age":21
};


var app = express();
var server = require("http").createServer(app);
var io = socketio(server);

var webapp = io.of("/webapp");
var NodeMCU = io.of("/NodeMCU");

webapp.use(middleware);
NodeMCU.use(middleware);


var port = process.env.PORT || 3000;


app.use ("/assets" ,express.static(__dirname +"/public"));
app.use (Parser.json());
app.use(Parser.urlencoded({extended:true}));
app.use(morgan("dev"));

app.set("view engine","ejs");

//db info
//console.log(config.getDb());
mongoose.connect(config.getDb());
Clmongoose.connect(configClock.getDb());

app.get("/",function(req,res){
    res.render("index");
});
//setupController(app);
todosController(app);
ClockController(app);


server.listen(port,function(err){
    if (err) throw err;
    console.log("App listening on port:"+ip.address()+":" + port);

});

NodeMCU.on("connection",function(socket){
    console.log("nodeMCU connected");
    socket.on("disconnect",function(){
        console.log("nodeMCU Disconnect ");
    });

    socket.on("Feeding",function(packet){


        webapp.emit("Feeding",packet);
        console.log(packet);
        var datecurrent = new Date();
        var data = {
            Temperature: packet.Temperature,
            Date: datecurrent
        };

        setupController(data);
        
    });
    socket.on("Data",function(packet){
        webapp.emit("Data",packet);
        var datecurrent = new Date();
        var data = {
            Temperature: packet.Temperature,
            Date: datecurrent
        };

        setupController(data);

        //du lieu nhiet do
        //update du lieu len database
    })
    socket.on("intervaltime",function(packet){
        webapp.emit("updateInterval",(packet.IntervalTime/60000));

    });
});

webapp.on("connection",function(socket){
    console.log("webapp connected");
    NodeMCU.emit("GetInterval",truongky);

    socket.on("start", function(packet){
        start.Numbers=parseInt(packet);
        console.log(start);
        NodeMCU.emit("start",start);
    });
    socket.on("stop", function(){
        NodeMCU.emit("stop",truongky);
        console.log("stop.........");
    });
    socket.on("WebupdateInterval",function(packet){
        var updateinterval = {
            IntervalTime :  parseInt(packet*60000)
        }
        console.log(packet);
        NodeMCU.emit("IntervalTime",updateinterval);
    });
    socket.on("Getinter",function(){
        NodeMCU.emit("GetInterval",truongky);
        console.log("getinterval");
    });


});
