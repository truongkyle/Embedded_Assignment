var configValue = require("./config");
module.exports = {
    getDb : function () {
        return `mongodb://${configValue.username}:${configValue.pass}@ds111410.mlab.com:11410/nodetodos`;
    }
}