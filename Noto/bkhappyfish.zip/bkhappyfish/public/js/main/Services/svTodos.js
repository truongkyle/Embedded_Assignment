var app = angular.module("app.todos")

app.factory("svTodos",["$http",function($http){

    return {
        get: function(){
            return $http.get('/api/todos');
           
        },
        creat: function(data){
            return $http.post("/api/todos",data)
        },
        update: function(data){
            return $http.put("/api/todos",data);
        },
        delete: function(id){
            return $http.delete("/api/todos/"+id);
        }
    };
}]);