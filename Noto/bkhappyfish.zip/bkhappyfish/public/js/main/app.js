var app = angular.module("app.todos", ["xeditable","btford.socket-io"]);

app.factory("svTodos",["$http","socketFactory",function($http,socketFactory){

    var myIoSocket = io.connect('/webapp');	

	mySocket = socketFactory({
		ioSocket: myIoSocket
	});
    
    return {
        get: function(){
            return $http.get('/api/Clocks');
           
        },
        creat: function(data){
            return $http.post("/api/Clocks",data)
        },
        update: function(data){
            return $http.put("/api/Clocks",data);
        },
        delete: function(id){
            return $http.delete("/api/Clocks/"+id);
        },
        MySocket:mySocket
       
    };
}]).controller("todoController", ['$scope','svTodos','$interval', function ($scope, svTodos, $interval) {

    $scope.appName = "HAPPY FISH";
    $scope.check = true;
    $scope.Temperature =0;
    $scope.Numbers = 0;
    $scope.NumbersClient = 0;
    $scope.formlist = {};
    $scope.List = [];
    $scope.loading= true;
    $scope.Clock =[];
    $scope.NumbersFeed=0;
    $scope.IntervalTime="5000";
   
    svTodos.get().then(function (response) {
        $scope.Clock = response.data;
        $scope.loading= false;

    });


    $interval(function(){
        var d = new Date();
        for(clock of $scope.Clock){
            if(clock.Min == d.getMinutes() && clock.Hour == d.getHours() && clock.Check == true){
                svTodos.MySocket.emit("start", clock.Numbers);
            }
            
        }
    },60000);

    $scope.creat = function () {
        $scope.loading= true;
        
        var form = {
            text: $scope.formlist.text,
            isDone: false
        }
        svTodos.MySocket.emit("start",form.text);
        svTodos.creat(form).then(function (response) {
            $scope.List = response.data;
        });
        $scope.loading= false;
        $scope.formlist.text = "";
    }
    $scope.deletelists = function (id) {
        $scope.loading= true;

        svTodos.delete(id).then(function (response) {
            $scope.List = response.data;
        });
    
        $scope.loading= false;
    };
    svTodos.MySocket.on("Feeding",function(data){
        $scope.NumbersClient = data.Numbers;
        $scope.Temperature = data.Temperature;
    });

    svTodos.MySocket.on("Data",function(data){
        $scope.Temperature = data.Temperature;
    })
    $scope.Stop= function(){
        svTodos.MySocket.emit("stop");
    }
    $scope.updateCLock= function(user){
        $scope.loading= true;
        svTodos.update(user).then(function (response) {
            $scope.Clock = response.data;
        });
        $scope.loading= false;
        
        
    }

    $scope.Feeding = function () {
        $scope.loading= true;  
        $scope.NumbersFeed = $scope.Numbers;
        var NumbersFeeding = $scope.Numbers;
        svTodos.MySocket.emit("start",NumbersFeeding);
        $scope.loading= false;
        $scope.Numbers = "";
    }
    $scope.UpdateInterval = function(){
        svTodos.MySocket.emit("WebupdateInterval",$scope.IntervalTime);
    };
    svTodos.MySocket.on("updateInterval",function(packet){
        $scope.IntervalTime = packet;
    });
    $scope.GetInterval = function(){
        svTodos.MySocket.emit("Getinter");
    }

}]);